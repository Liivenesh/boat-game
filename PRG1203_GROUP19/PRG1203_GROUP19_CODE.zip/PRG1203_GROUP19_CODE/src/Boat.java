import java.util.Scanner;

public class Boat {
	
	//attributes
	private String name;
	private int position = 0;
	private Dice d = new Dice();

	//setter & getter
	public String getName() {
		return name;
	}
	
	public void setName(int num) {
		Scanner scanner = new Scanner (System.in);
		
		System.out.printf("Enter your %d name: ", num);
		name = scanner.next();
		
	}
	
	
	public int getPosition() {
		return position;
	}
	
	public void setPosition(int strength) {
		position = position + strength;
	}
	
	public int getNumRolls() {
		return d.getNumRolls();
	}
	
	//other methods
	
	public void rollDice(){
		Scanner pause = new Scanner (System.in);
		System.out.print(name + ", it's your turn to roll the dice!");
		
		pause.nextLine();
		d.roll();
		
		System.out.print("Your dice number is " + d.getDice() + "\n");
		
		if (position + d.getDice() <= 100){
			position = position + d.getDice();
		}
	}

	public void reCalculate(int value) {
		if ((position + value ) <= 100)
				position = position + value;
	}
}
