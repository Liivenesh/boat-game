public class RiverObject{

	private int location;
	private String symbol;
	protected int strength;
	
	//constructor
	public RiverObject(String s) {
		symbol = s;
	}
	
	//setter/getter
	public void setLocation(int l) {
		location = l;
	}
	
	public int getLocation() {
		return location;
	}
	
	public String getSymbol() {
		return symbol;
	}
	
	public void setSymbol(String symbol) {
		this.symbol = symbol;
	}
	
	public void setStrength(int s) {
		strength = s;
	}
	
	public int getStrength() {
		return strength;
	}
}
