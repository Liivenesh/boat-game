import java.util.Random;

public class Fish extends RiverObject{
	
	//constructor
	public Fish() {
		super("F");
		Random r = new Random();
		setLocation(r.nextInt(99));
	}
}
