public class Dice {
	
	//attributes
	private int numRolls;
	private int diceRoll;
	
	//setter & getter
	public int getDice() {
		return diceRoll;
	}
	
	public int getNumRolls() {
		return numRolls;
	}
	
	//other methods
	public void roll() {
		diceRoll = (int)((Math.random() * 6) + 1);
		numRolls++;
	}
}
