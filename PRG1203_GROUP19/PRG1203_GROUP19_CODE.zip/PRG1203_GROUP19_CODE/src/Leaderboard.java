import java.io.*;
import java.util.ArrayList;
import java.util.Collections;

public class Leaderboard {
	
	//attributes
	private static ArrayList<String> temp = new ArrayList<String>();
	private static FileWriter fw = null;
	private static BufferedWriter bw = null;
	private static PrintWriter pw = null;
	
	//other methods
	public static void createLeaderboard() {
		try {
			File file1 = new File("database1.txt");
			file1.createNewFile();
		}
		catch (IOException e) {
			System.out.println("An error has occured.");
			e.printStackTrace();
		}
	}
	public static void readLeaderboard() throws FileNotFoundException {
		
		sortLeaderboard();
		
		int n = 0;
		System.out.println("\n");
		System.out.println("LEADERBOARD");
		System.out.println("============");
		System.out.println("Score   Name");
		System.out.println("============");
		
		try {
			FileReader fr = new FileReader("database1.txt");
			BufferedReader br1 = new BufferedReader(fr);
			String name;
			while (n<5) {
				name = br1.readLine();
				System.out.println(name);
				n++;
			}
			fr.close();
		}
		catch(Exception e) {
			System.err.println("Error" + e.getMessage());
		}
	}
	
	public static void addToLeaderboard(String name, String score) throws IOException {
		try {
			fw = new FileWriter("database1.txt", true);
			bw = new BufferedWriter(fw);
			pw =new PrintWriter(bw);
			
			pw.write(score + "     ");
			pw.write(name);
			pw.flush();
			
		} finally {
			try {
				pw.close();
				bw.close();
				fw.close();
			} catch (IOException io) {
				io.printStackTrace();
			}
		}
	}
		
	private static void sortLeaderboard() {
		temp.clear();
		
		try {
		FileReader fr = new FileReader("database1.txt"); 
		BufferedReader br = new BufferedReader(fr); 
		String name;
			while((name = br.readLine())!= null) { 
				temp.add(name);
			}
			
			Collections.sort(temp);
			fr.close();
			
			try (FileWriter fw = new FileWriter("database1.txt")) {
				int count = 0;
				
				for (String s: temp) {
					fw.write(s + "\n");
					count++;
					
					if (count >=5) {
						break;
					}
				}
			} catch (Exception e) {
				System.err.println("Error " + e.getMessage());
		} finally {
			if (fw != null) {
				fw.close();
			}
	}
	} catch(Exception e) {	
	System.err.println("Error" + e.getMessage());
	}
}
}




