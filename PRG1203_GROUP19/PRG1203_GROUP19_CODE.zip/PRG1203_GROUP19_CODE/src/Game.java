import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.*;

public class Game{
	Scanner scanner = new Scanner (System.in);
	
	//attributes
	private River river;
	private Boat b1 = new Boat();
	private Boat b2 = new Boat();
	private static String winner;
	private static String winnerRolls;
	
	//constructor
	public Game() {
		river = new River();
	}
	
	//setter & getter
	public String getWinnerName() {
		return winner;
	}
	
	public void setWinnerName(String w) {
		winner = w;
	}
	
	public String getWinnerRolls() {
		return winnerRolls;
	}
	
	public void setWinnerRolls(String r) {
		winnerRolls = r;
	}
	
	//other methods
	public void start() throws IOException {
		b1.setName(1);
		b2.setName(2);
		
		do {
			System.out.print("\n");
			b1.rollDice();
			System.out.print("\n");
			b2.rollDice();
			
			displayPosition();
			
			checkPosition(b1);
			checkPosition(b2);
			
			
		}while(b1.getPosition() != 100 && b2.getPosition() != 100);
		
		if (b1.getPosition() == 100) {
			System.out.print("Congratulations " + b1.getName() + "! You have won the game! Check out the leaderboard to see your position :).\n");
			setWinnerName(b1.getName());
			setWinnerRolls(Integer.toString(b1.getNumRolls()));
		}
		else {
			System.out.print("Congratulations " + b2.getName() + "! You have won the game! Check out the leaderboard to see your position :).\n");
			setWinnerName(b2.getName());
			setWinnerRolls(Integer.toString(b2.getNumRolls()));
		}
		
	Leaderboard.createLeaderboard();
	Leaderboard.addToLeaderboard(getWinnerName(), getWinnerRolls());
	Leaderboard.readLeaderboard();
		
	}
	
	public void checkPosition(Boat b){
		if(river.checkPosition(b.getPosition()) == "T" || river.checkPosition(b.getPosition()) == "F" || river.checkPosition(b.getPosition()) == "C") {
			if (river.checkPosition(b.getPosition()) == "T") {
				System.out.println("The player " + b.getName() + " got stuck in a trap!");
				System.out.println("You're pushed back " + river.checkStrength(b.getPosition())+ " step(s)!");
				b.reCalculate(river.checkStrength(b.getPosition()));
				displayPosition();
				checkPosition(b);
			}
			
			else if(river.checkPosition(b.getPosition()) == "C") {
				System.out.println("The player " + b.getName() + " entered a current!");
				System.out.println("You're pushed forward " + river.checkStrength(b.getPosition())+ " step(s)!");
				b.reCalculate(river.checkStrength(b.getPosition()));
				displayPosition();
				checkPosition(b);
			}
			
			else {
				System.out.println("The player " + b.getName() + " has met a magical fish!");
				b.rollDice();
				displayPosition();
				checkPosition(b);
			}
		}
	}
	
	public void displayRiver() {
			System.out.print("\n");
			for (int i = 0; i < 100; i++) {
				System.out.print("~");
			}	
			System.out.print("\n");
			
			river.displayRiver();
			System.out.print("\n");
			
			for (int i = 0; i < 100; i++) {
				System.out.print("~");
			}	
			System.out.print("\n");
	}
	
	public void displayPosition() {
		displayRiver();
		for (int i = 0; i < 100; i++) {
			if (b1.getPosition() == i) {
				System.out.print("1");
			}
			else if (b2.getPosition() == i) {
				System.out.print("2");
			}
			
			else if (b1.getPosition() == i && b2.getPosition() == i) {
				System.out.print("1");
			}
			
			else if (b1.getPosition() != i && b2.getPosition() != i) {
				System.out.print(" ");
			}
		}
		System.out.println("\nPosition of Player 1: " + b1.getPosition());
		System.out.println("Position of Player 2: " + b2.getPosition());
	}
	
	public static char displayMenu() throws FileNotFoundException {  //menu
		Scanner scanner = new Scanner (System.in);
		System.out.print("\nWelcome to BOAT:The Game!\n\n");
		System.out.print("(1) Start the game\n\n");
		System.out.print("(2) Instructions\n\n");
		System.out.print("(3) Leaderboard\n\n");
		System.out.print("(4) Quit game\n\n");
		System.out.print("Enter your response:");
		Leaderboard.readLeaderboard();
		
		char response = scanner.next().charAt(0);
		while(response!='1' && response!='2' && response!='3' && response!='4') {
			System.out.print("Enter a valid response!:");
			response = scanner.next().charAt(0);
		}
		
		return response;
	}
}


