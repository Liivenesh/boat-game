import java.io.IOException;
import java.util.*;

public class TestGame {
	
	static ArrayList<Boat> scoreList = new ArrayList<Boat>();

	public static void main(String[] args) throws IOException {
		Scanner scanner = new Scanner(System.in);
		char response;
		
		do {	
			response = Game.displayMenu();
			
			if (response == '1') {
					Game g = new Game();
					g.start();
			}
			
			else if (response == '2') {
				System.out.print("------------------------------------------------------------------\n");
				System.out.print("--------------------------- INSTRUCTIONS -------------------------\n");
				System.out.print("------------------------------------------------------------------\n");
				System.out.print("\n");
				System.out.print("1. Enter your name, Player 1!\n");
				System.out.print("2. Enter your name, Player 2!\n");
				System.out.print("3. Player 1 starts first! Enter any key to roll the dice.\n");
				System.out.print("4. Player 2 then rolls the dice.\n");
				System.out.print("5. Once the boats have sailed, beware of the traps and be thankful for the currents!\n");
				System.out.print("6. The first one that arrives at the end of the river wins!\n");
				System.out.print("\n");
				System.out.print("P.S If you're lucky enough, you might get to see a magical fish!\n");
				System.out.print("\n");
				System.out.print("---------------------------- GOOD LUCK ---------------------------\n");
			}
			
			else if (response == '3') {
				System.out.print("\nCheck out who is in the lead!");
				Leaderboard.readLeaderboard();
			}
			
			else if (response == '4') {
				System.out.print("That's a pity :( . It's alright, you can always play again next time! Adios, mi amigo!");
				System.exit(0);
			}
			
			System.out.print("\n\nDo you want to play the game again?");
			System.out.print("\nEnter 'Y' or 'y' to play again.");
			System.out.print("\nEnter any other key to end the game.");
			response = scanner.next().charAt(0);
			
		} while (response=='y' || response == 'Y');	
		System.out.print("\n                __/___            \r\n"
				+ "          _____/______|           \r\n"
				+ "  _______/_____\\_______\\_____     \r\n"
				+ "  \\              < < <       |    \r\n"
				+ "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
		System.out.print("\nThe boats have returned back to the dock!\n");
		System.out.print("\nThank you for playing our game! Sayonara!\n");
		System.exit(0);
	} 
}

	
