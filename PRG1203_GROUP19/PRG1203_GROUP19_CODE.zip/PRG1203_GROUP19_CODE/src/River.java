import java.util.ArrayList;
import java.util.Random;

public class River {
	//attributes
	private ArrayList<RiverObject> objList = new ArrayList<RiverObject>();
	
	//constructor
	public River() {
		Random r = new Random();
		int no_of_current = r.nextInt(10);
		int no_of_trap = r.nextInt(10);
		int no_of_fish = r.nextInt(3); 

		for (int i=0; i < no_of_current; i++) {
			objList.add(new Current());
		}
	
		for (int i=0; i < no_of_trap; i++) {
			objList.add(new Trap());
		}
	
		for (int i=0; i < no_of_fish; i++) {
			objList.add(new Fish());
		}
	}
	
	//other methods
	public String checkPosition(int position) {
		String symbol = null;
		
		for (int i = 0; i < 100; i++) {
			for(RiverObject r: objList) {
				if (r.getLocation() == position) {
					if (r.getSymbol() == "T") {
						symbol = "T";
					}
					
					if (r.getSymbol() == "C") {
						symbol = "C";
					}
					
					if (r.getSymbol() == "F") {
						symbol = "F";
					}
				}
			}
		}
		
		return symbol;
	}
	
	public int checkStrength(int position) {
		int strength = 0;
		
		for (int i = 0; i < 100; i++) {
			for(RiverObject r: objList) {
				if (r.getLocation() == position) {
					if (r.getSymbol() == "T") {
						strength = r.getStrength() * -1;
					}
					
					if (r.getSymbol() == "C") {
						strength = r.getStrength() ;
					}
					
				}
			}
		}
		
		return strength;
	}
	
	public void displayRiver() {
		for (int i = 0; i < 100; i++) {
			boolean isObject = false;
			for(RiverObject r: objList) {
				if (r.getLocation() == i) {
					isObject = true;
					System.out.print(r.getSymbol());
				}
			}
			
			if(!isObject) {
				System.out.print(" ");
				
			}	
		}
	}
}

