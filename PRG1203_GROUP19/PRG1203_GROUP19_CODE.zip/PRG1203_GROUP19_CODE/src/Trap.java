import java.util.Random;

public class Trap extends RiverObject {

	//constructor
	public Trap() {
		super("T");
		Random r = new Random();
		strength = 1 + r.nextInt(5);
		setStrength(strength); 
		setLocation(r.nextInt(99));	
	}
}
