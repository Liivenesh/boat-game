import java.util.Random;

public class Current extends RiverObject {
	
	//constructor
	public Current() {
		super("C");
		Random r = new Random();
		strength = 1 + r.nextInt(5);
		setStrength(strength); 
		setLocation(r.nextInt(99));
	}
}
